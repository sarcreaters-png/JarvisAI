# JARVIS AI — Android project

This is the Kotlin + Jetpack Compose starter app. It is a development MVP, not yet a full phone-controlling assistant.

## Build an APK for free using GitHub Actions (phone-only workflow)

1. Create/sign in to a GitHub account at https://github.com.
2. In GitHub, create a **new public repository** named `JarvisAI` (public repositories allow free GitHub Actions use within GitHub's current policy/limits).
3. On the repository page choose **Add file → Upload files**.
4. Extract this ZIP on your phone first. Upload the *contents* of the `JarvisAI` folder (including `.github`, `app`, `build.gradle.kts`, `settings.gradle.kts`, etc.) to the repository root. Make sure `.github/workflows/build-apk.yml` is uploaded.
5. Commit the upload to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build JARVIS AI APK**, then **Run workflow** if it did not start automatically.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run, scroll to **Artifacts**, and download `JARVIS-AI-debug-APK`.
9. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Tap it to install on your Android phone; approve the Android install prompt if asked.

The workflow uses JDK 17 and Gradle 8.7, compatible with the Android Gradle Plugin 8.5.2 used by this project. GitHub Actions usage is subject to account limits and policies; no paid service is required for a public repository.

## Gemini setup

After installing, open the app's Settings and enter your own Gemini API key. Get a key from https://aistudio.google.com/app/apikey. Keep it private. API availability and free quotas depend on Google's current terms and selected model.

## Included MVP features

- Dark JARVIS dashboard and chat interface
- Gemini-powered text chat with runtime API key/model settings
- Android speech-recognition intent for voice input (device speech service required)
- YouTube search shortcut
- Coding and notes prompt shortcuts

## Important limitations

- This is not a complete JARVIS phone-control system.
- The Apps shortcut currently opens Android Settings; arbitrary app launching and screen control are not implemented.
- YouTube opens a search page; it does not guarantee autoplay.
- Spoken AI responses, guaranteed female TTS voice, wake-word detection, long-term memory, accessibility-based screen automation, and secure remote code execution are not implemented.
- For production distribution, do not embed a personal Gemini API key in a public APK. Use a secure backend proxy.

## Local build

Open the `JarvisAI` folder in Android Studio with Android SDK installed, then run `gradle :app:assembleDebug` (or use the IDE's Build APK action).
