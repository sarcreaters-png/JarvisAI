# JARVIS AI – Architecture (MVVM, single module, package-by-layer)

app/src/main/java/com/jarvis/ai/
  MainActivity.kt          entry point
  domain/                  models, interfaces (AiProvider, Tool) – Stage 3+
  data/                    Room, DataStore, Gemini client, secure key store – Stage 3+
  ai/                      AiProvider interface + GeminiProvider (swappable models)
  voice/                   SpeechRecognizer, TextToSpeech, wake word – Stage 5
  control/                 intents + AccessibilityService – Stage 6
  tools/                   youtube, coding, notes, todo, weather… (modular Tool plugins)
  ui/theme, ui/components, ui/main, ui/settings

Why this stack: Kotlin + Compose + Material3 + MVVM as requested. Hilt, Room and
DataStore get added when the stage needing them arrives. API key: stored with
EncryptedSharedPreferences/Keystore (never hardcoded). Code execution: remote sandbox only.
