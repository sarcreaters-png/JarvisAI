package com.jarvis.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF050B1A)
val NavyLight = Color(0xFF0B1630)
val Cyan = Color(0xFF00E5FF)
val Blue = Color(0xFF2979FF)
val GlassFill = Color(0x1A5AA9FF)
val GlassBorder = Color(0x4D00E5FF)

private val Scheme = darkColorScheme(
    primary = Cyan, secondary = Blue, background = Navy, surface = NavyLight,
    onPrimary = Navy, onBackground = Color(0xFFE6F6FF), onSurface = Color(0xFFE6F6FF)
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
