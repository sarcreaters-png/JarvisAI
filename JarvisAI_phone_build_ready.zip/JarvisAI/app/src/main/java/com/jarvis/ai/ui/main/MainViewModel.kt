package com.jarvis.ai.ui.main

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.domain.AiState
import com.jarvis.ai.domain.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

 data class MainUiState(
    val aiState: AiState = AiState.IDLE,
    val messages: List<ChatMessage> = emptyList(),
    val input: String = "",
    val apiKey: String = "",
    val model: String = "gemini-2.5-flash",
    val settingsOpen: Boolean = false
)

class MainViewModel : ViewModel() {
    private val _ui = MutableStateFlow(MainUiState())
    val ui: StateFlow<MainUiState> = _ui.asStateFlow()
    private val gemini = GeminiClient()
    private var preferences: android.content.SharedPreferences? = null
    private var nextId = 1L

    fun initialize(context: Context) {
        if (preferences != null) return
        preferences = context.applicationContext.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)
        val prefs = preferences!!
        _ui.update { it.copy(apiKey = prefs.getString("gemini_key", "").orEmpty(), model = prefs.getString("gemini_model", "gemini-2.5-flash").orEmpty()) }
    }

    fun onInput(text: String) = _ui.update { it.copy(input = text) }
    fun openSettings() = _ui.update { it.copy(settingsOpen = true) }
    fun closeSettings() = _ui.update { it.copy(settingsOpen = false) }
    fun saveSettings(key: String, model: String) {
        val cleanModel = model.trim().ifBlank { "gemini-2.5-flash" }
        preferences?.edit()?.putString("gemini_key", key.trim())?.putString("gemini_model", cleanModel)?.apply()
        _ui.update { it.copy(apiKey = key.trim(), model = cleanModel, settingsOpen = false) }
    }

    fun send() {
        val prompt = _ui.value.input.trim()
        if (prompt.isEmpty() || _ui.value.aiState == AiState.THINKING) return
        val oldMessages = _ui.value.messages
        val userMessage = ChatMessage(nextId++, prompt, true)
        _ui.update { it.copy(messages = it.messages + userMessage, input = "", aiState = AiState.THINKING) }
        val history = oldMessages.map { it.fromUser to it.text }
        val key = _ui.value.apiKey
        val model = _ui.value.model
        viewModelScope.launch {
            val answer = runCatching { withContext(Dispatchers.IO) { gemini.generate(key, model, prompt, history) } }
                .getOrElse { "I couldn't connect just now. ${it.message ?: "Please check your connection and Gemini settings."}" }
            _ui.update { it.copy(messages = it.messages + ChatMessage(nextId++, answer, false), aiState = AiState.IDLE) }
        }
    }

    fun toggleMic() = _ui.update { it.copy(aiState = if (it.aiState == AiState.LISTENING) AiState.IDLE else AiState.LISTENING) }
}
