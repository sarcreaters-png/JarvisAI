package com.jarvis.ai.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jarvis.ai.ui.theme.GlassBorder
import com.jarvis.ai.ui.theme.GlassFill

/** Glassmorphism-style translucent panel. */
@Composable
fun GlassCard(modifier: Modifier = Modifier, corner: Dp = 20.dp, content: @Composable () -> Unit) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(corner),
        color = GlassFill,
        border = BorderStroke(1.dp, GlassBorder)
    ) { Box { content() } }
}
