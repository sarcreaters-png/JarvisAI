package com.jarvis.ai.domain

/** Drives the animated core, wave and status text. Later stages set these from Gemini/STT/TTS. */
enum class AiState(val label: String) {
    IDLE("Online • Standing by"),
    LISTENING("Listening…"),
    THINKING("Thinking…"),
    SPEAKING("Speaking…")
}

data class ChatMessage(val id: Long, val text: String, val fromUser: Boolean)
