package com.jarvis.ai.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.jarvis.ai.domain.AiState
import com.jarvis.ai.ui.theme.Blue
import com.jarvis.ai.ui.theme.Cyan
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun WaveForm(state: AiState, modifier: Modifier = Modifier) {
    val amp = when (state) {
        AiState.IDLE -> 0.08f; AiState.LISTENING -> 0.7f; AiState.THINKING -> 0.3f; AiState.SPEAKING -> 0.9f
    }
    val phase by rememberInfiniteTransition(label = "wave")
        .animateFloat(0f, 6.2832f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "phase")
    Canvas(modifier.fillMaxWidth().height(48.dp)) {
        val bars = 31
        val gap = size.width / bars
        val bw = gap * 0.55f
        for (i in 0 until bars) {
            val env = 1f - abs(i - bars / 2f) / (bars / 2f) * 0.6f
            val h = (size.height * (0.12f + amp * env * (0.5f + 0.5f * sin(phase + i * 0.5f)))).coerceAtLeast(4f)
            drawRoundRect(
                Brush.verticalGradient(listOf(Cyan, Blue)),
                Offset(i * gap + (gap - bw) / 2, (size.height - h) / 2),
                Size(bw, h), CornerRadius(bw / 2)
            )
        }
    }
}
