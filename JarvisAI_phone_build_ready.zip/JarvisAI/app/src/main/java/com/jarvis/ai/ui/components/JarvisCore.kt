package com.jarvis.ai.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jarvis.ai.domain.AiState
import com.jarvis.ai.ui.theme.Blue
import com.jarvis.ai.ui.theme.Cyan

/** Animated circular AI core. Speed and glow react to [state]. */
@Composable
fun JarvisCore(state: AiState, modifier: Modifier = Modifier, size: Dp = 220.dp) {
    val speed = when (state) {
        AiState.IDLE -> 1f; AiState.LISTENING -> 2f; AiState.THINKING -> 4f; AiState.SPEAKING -> 2.5f
    }
    val t = rememberInfiniteTransition(label = "core")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween((12000 / speed).toInt(), easing = LinearEasing)), label = "spin")
    val spinRev by t.animateFloat(360f, 0f, infiniteRepeatable(tween((18000 / speed).toInt(), easing = LinearEasing)), label = "rev")
    val pulse by t.animateFloat(0.85f, 1.1f, infiniteRepeatable(tween((1800 / speed).toInt(), easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")

    Box(modifier.size(size)) {
        Canvas(Modifier.size(size)) {
            val c = center
            val r = this.size.minDimension / 2
            // glow
            drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.35f), Color.Transparent), c, r), r, c)
            // core orb
            drawCircle(Brush.radialGradient(listOf(Color.White, Cyan, Blue, Color.Transparent), c, r * 0.45f * pulse), r * 0.45f * pulse, c)
            // outer dashed ring
            rotate(spin, c) {
                drawCircle(Cyan.copy(alpha = 0.8f), r * 0.95f, c,
                    style = Stroke(3.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(18f, 14f))))
            }
            // arc segments
            rotate(spinRev, c) {
                for (i in 0 until 3) {
                    drawArc(Blue, i * 120f, 80f, false,
                        Offset(c.x - r * 0.75f, c.y - r * 0.75f), Size(r * 1.5f, r * 1.5f),
                        style = Stroke(6.dp.toPx(), cap = StrokeCap.Round))
                }
            }
            rotate(spin * 1.5f, c) {
                drawArc(Cyan, 0f, 100f, false,
                    Offset(c.x - r * 0.58f, c.y - r * 0.58f), Size(r * 1.16f, r * 1.16f),
                    style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
            }
        }
    }
}
