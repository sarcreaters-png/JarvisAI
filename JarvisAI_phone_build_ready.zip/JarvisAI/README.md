# JARVIS AI – Android starter MVP

A Kotlin + Jetpack Compose Android project with a futuristic JARVIS interface and a Gemini-powered chat flow.

## Included in this version
- Dark, animated JARVIS dashboard and chat interface.
- Gemini API key and model configuration in Settings (key is not hard-coded).
- Gemini `generateContent` requests with a short conversation history.
- Android speech-recognition intent for voice input (requires a compatible speech service on the device).
- YouTube music search shortcut.
- Coding and notes prompt shortcuts.

## Open in Android Studio
1. Open the `JarvisAI` folder.
2. Allow Android Studio to sync Gradle and install the Android SDK required by the project.
3. Run the `app` configuration on an Android device or emulator (Android 8.0 / API 26 or newer).
4. Open Settings in the app and paste your Gemini API key. The default model is `gemini-2.5-flash`; change it if your API project uses another available model.

## Important limitations
This is an MVP, not a full system-level assistant yet. The Apps shortcut currently opens Android Settings; Android restricts arbitrary app launching and background device control. YouTube opens a search page and does not force autoplay. Voice input depends on the device's installed speech-recognition service. Spoken AI replies, a guaranteed female TTS voice, wake-word detection, accessibility-based screen control, persistent long-term memory, and remote code execution are not implemented in this version. Code execution should only be added through a secure remote sandbox, never by running untrusted generated code directly on the phone.

## API key safety
The Gemini key is entered at runtime and is not committed into source code. It is stored in app-private preferences on the device. For a production release, use a backend proxy so a distributable APK does not contain a reusable personal API key.
